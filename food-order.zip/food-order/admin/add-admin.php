
<?php
include('partials/menu.php');
?>
<div class="wrapper">
    <h1>ADD ADMIN</h1>
    <?php

if(isset($_SESSION['add']))
{
    echo $_SESSION['add'];
    unset($_SESSION['add']);
}
     ?>
    <form action="" method="POST">
        <table>
            <tr>
                <td>Fullname:<br><input type="text" name="fname" placeholder="Enter admin full name"></td></tr>
               <tr> <td>Username:<br><input type="text" name="uname" placeholder="Enter  username"></td></tr>
                <tr><td>Password:<br><input type="text" name="pass" placeholder="Enter new password"></td></tr>
               <tr> <td>Confirm-Password:<br><input type="text" name="cpass" placeholder="confirm password"></td></tr>
                <tr><td><input type="submit"  name="submit" value="save as admin"></td></tr>

            </tr>
        </table>
    </form>
</div>

<?php
include('partials/footer.php');
?>

<?php
if(isset($_POST['submit']))
{
$fname=$_POST['fname'];
$uname=$_POST['uname'];
$pass=$_POST['pass'];

$sql="insert into admin(fullname,username,password)values('$fname','$uname','$pass')";
$res=mysqli_query($con,$sql);
if($res)
{
    $_SESSION['add']= "admin added successfully";

    header("location:".siteurl.'admin/manage-admin.php');

}
else{
    die(mysqli_connect_error($con));
    
    $_SESSION['add']= "failed to  added successfully";

    header("location:".siteurl.'admin/add-admin.php');
}
}




?>