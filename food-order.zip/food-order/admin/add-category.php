
<?php
include('partials/menu.php');
?>


<div class="main-content">
    <div class="wrapper">
     <h1>Add new Category</h1>
     <br><br>
    
    <form method="post" action="" enctype="multipart/form-data">
        tittle:<input type="text" name="title" placeholder="Enter category tittle"><br><br>

        Image:<input type="file" name="img" ><br><br>
        
        featured:<input type="radio" name="featured" value="YES">YES
        <input type="radio" name="featured" value="NO">NO<br><br>
        Active:<input type="radio" name="Active" value="YES">
       YES <input type="radio" name="Active" value="NO">No<br><br>
        <input type="submit" value="save" name="submit">
        </form>
    
    </div>
</div>

<?php
if(isset($_POST['submit']))
{
   $title=$_POST['title'];
   $feature=$_POST['featured']; 
   $active=$_POST['Active'];
   if(isset($_FILES['img']['name']))
   {
     $image=$_FILES['img']['name'];
     $sourse_path=$_FILES['img']['tmp_name'];
     $des_path="../images/category/".$image;
     $upload=move_uploaded_file($sourse_path,$des_path);
     if($upload==false)
     {
        $_SESSION['upload-fail']="file uploading is falied";
     }

   }


   
   $sql="insert into category (title,image,featured,active)values('$title','$image','$feature','$active')";
   $res=mysqli_query($con,$sql);
   if($res)
   {
    $_SESSION['add-category']= "category added succesfully";
    header("location:".siteurl.'admin/manage-category.php');
    
   }

}

?>














<?php
include('partials/footer.php');
?>