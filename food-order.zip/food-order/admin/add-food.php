
<?php
include('partials/menu.php');
?>
<div class="wrapper">
    <h1>ADD FOOD</h1>
    <?php

if(isset($_SESSION['add']))
{
    echo $_SESSION['add'];
    unset($_SESSION['add']);
}
     ?>
    <form action="" method="POST" enctype="multipart/form-data">
        <table>
            <tr>
                <td>Title:<br><input type="text" name="title" placeholder="title of the food"></td></tr>

               <tr> <td>Description:<br><input type="text" name="description" placeholder="description of the food"></td></tr>
                <tr><td>Price:<br><input type="number" name="price" placeholder="price of food"></td></tr>
               
                <tr> <td>Image:<br><input type="file" name="image" ></td></tr>
               <tr><td>Categrory:</td>
               <td>
                <select name="category">
                  <?php


                   $sql="select * from category where active='yes'";

                   $res=mysqli_query($con,$sql);

                   $count=mysqli_num_rows($res);

                   if($count>0)
                   {
                    while($row=mysqli_fetch_assoc($res))
                {
                     $id=$row['id'];
                     $title=$row['title'];
                     ?>
                     <option value="<?php echo $id; ?> "><?php echo $title; ?></option>
                     <?php
                }
                   }
                   else
                   {
                    ?>
                    <option value="0">NO category found</option>
                    <?php
                   }


                   


                    ?>


                </select>
               </td>
            

               </tr>
               <tr>
                <td>featured: 
                <input type="radio" name="featured" value="YES">yes
                <input type="radio" name="featured" value="NO">NO
                </td>
               </tr>
               
               <tr>
                <td>Active: 
                <input type="radio" name="active" value="YES">yes
                <input type="radio" name="active" value="NO">NO
                </td>
               </tr>
               

                <tr><td><input type="submit"  name="submit" value="save food"></td></tr>

            </tr>
        </table>
    </form>
</div>

<?php
include('partials/footer.php');
?>

<?php
if(isset($_POST['submit']))
{
$title=$_POST['title'];
$description=$_POST['description'];
$price=$_POST['price'];
$category=$_POST['category'];
if(isset($_POST['featured']))
{
    $featured=$_POST['featured'];
}
else
{
    $featured="NO";
}
if(isset($_POST['active']))
{
$active=$_POST['active'];

}
else
{
    $active="NO";
}

if(isset($_FILES['image']['name']))
{
$image=$_FILES['image']['name'];

    $src_path=$_FILES['image']['tmp_name'];
    $dst_path="../images/food/".$image;

    $upload=move_uploaded_file($src_path,$dst_path);
if($upload==false)
{
    $_SESSION['upload']="failed to upload image";

}

}
$sql="insert into food (title,description,price,image_name,category_id,featured,active)values('$title','$description','$price','$image','$category','$featured','$active')";
$res=mysqli_query($con,$sql);
if($res)
{
    $_SESSION['add-food']= "food added successfully";

    header("location:".siteurl.'admin/manage-food.php');
}
}
?>