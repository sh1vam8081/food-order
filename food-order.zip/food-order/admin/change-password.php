<?php
include('partials/menu.php');
?>



<div class="main-content">
    <div class="wrapper">
     <h1>Change Password</h1>

     <?php 
     $id=$_GET['id']; 

     $sql






?>

     

     <form action="" method="POST">
        <table>
            <tr>
                <tr><td>Id:<?php echo $id; ?></td></tr>
            
                <tr><td><br><input type="hidden" name="id" value="<?php echo $id; ?>"></td></tr>

                <tr><td>Current password:<br><input type="text" name="pass" placeholder="Enter current password"></td></tr>
               <tr> <td>New Password:<br><input type="text" name="npass" placeholder="Enter new password" ></td></tr>
               <tr> <td>Confirm Password:<br><input type="text" name="cnpass" placeholder="Re-Enter new password"></td></tr>

                <tr><td><input type="submit"  name="submit" value="save"></td></tr>

            </tr>
        </table>
</form>

    </div>
</div>
<?php

if(isset($_POST['submit']))
{
    $id=$_POST['id'];
    $pass=$_POST['pass'];
    $npass=$_POST['npass'];
    $cnpass=$_POST['cnpass'];

    $sql="select * from admin where id='$id' AND password='$pass' ";
    $res=mysqli_query($con,$sql);
    if($res==true)
    {
    $count=mysqli_num_rows($res);
    if($count==1)
    
    {
        echo "user is  find";


           if($npass==$cnpass)   
           {

              $sql2="update admin set password='$npass' where id='$id'";
              $res1=mysqli_query($con,$sql2);
              if($res1)
              {
                $_SESSION['change-password']="password change successfully";
                header("location:".siteurl.'admin/manage-admin.php');
              }
           }
           else
           {
            
           $_SESSION['password-unmatched']= "confirm password and new password not same";
           header("location:".siteurl.'admin/manage-admin.php');
           }




       }
       else
       {
        
           $_SESSION['user-not-found']= "user does not found";
           header("location:".siteurl.'admin/manage-admin.php');
       }
    
    }


}





?>

<?php
include('partials/footer.php');
?>