<?php

session_start();
define('siteurl','http://localhost:8081/food-order/');

$con=mysqli_connect("localhost","root","","food-order");
if(!$con){
die(mysqli_connect_error($con));
}

?>