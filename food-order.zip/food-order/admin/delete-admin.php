<?php
include('partials/menu.php');
?>
<?php



$id=$_GET['id'];

$sql="delete from admin where id='$id'";

$res=mysqli_query($con,$sql);
if($res)
{
    $_SESSION['delete']= "data deleted successfully";
    header("location:".siteurl.'admin/manage-admin.php');
}

?>
<?php
include('partials/footer.php');
?>