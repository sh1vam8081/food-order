<?php
include('partials/menu.php');
?>
<?php




if(isset($_GET['id']) AND isset($_GET['image_name']))
{
  $id=$_GET['id'];
  $image=$_GET['image_name'];

  if($image !="")
  {

    $path="../images/category/".$image;
  }
  
  $remove=unlink($path);

    
  $sql="delete from category where id='$id' ";

  $res=mysqli_query($con,$sql);
  if($res)
  {
      $_SESSION['delete-category']= "category deleted successfully";
      header("location:".siteurl.'admin/manage-category.php');
  }


}


?>
<?php
include('partials/footer.php');
?>