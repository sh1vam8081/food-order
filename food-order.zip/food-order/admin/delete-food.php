<?php
include('partials/menu.php');
?>
<?php



$id=$_GET['id'];

$sql="delete from food where id='$id'";

$res=mysqli_query($con,$sql);
if($res)
{
    $_SESSION['delete-food']= "food deleted successfully";
    header("location:".siteurl.'admin/manage-food.php');
}

?>
<?php
include('partials/footer.php');
?>