


<?php
 include "connectdb.php";

 $id=$_GET['id'];

 $sql="delete from tbl_order where id=$id";

 $res=mysqli_query($con,$sql);

 if($res)
 {
   $_SESSION['order-cancel']="order cancelled successfully";
   header("location:".siteurl.'admin/manage-order.php');
 }else{
    echo "order not deleted";
 }







?>
