<?php
include('partials/menu.php');
?>


    <!-- main-content part starts -->
    <div class="main-content">
    <div class="wrapper">
        
     <h1>Dashboard</h1>
    <div class="col-4 text-center">
        <?php
    
        $sql="select * from category";
        $res=mysqli_query($con,$sql);
        $count=mysqli_num_rows($res);
        ?>
        <h1><?php echo $count; ?></h1>

        <?php
?>
        
        Categories    
    </div>
    <div class="col-4 text-center">
    <?php
    
    $sql="select * from food";
    $res=mysqli_query($con,$sql);
    $count=mysqli_num_rows($res);
    ?>
    <h1><?php echo $count; ?></h1>

    <?php
?>
        
        Foods   
    </div>
    <div class="col-4 text-center">
    <?php
    
    $sql="select * from tbl_order";
    $res=mysqli_query($con,$sql);
    $count=mysqli_num_rows($res);
    ?>
    <h1><?php echo $count; ?></h1>

    <?php
?>
    
    

        Orders   
    </div>
    <div class="col-4 text-center">
        <?php
        $sql2="select sum(total) as Total from tbl_order";
        $res=mysqli_query($con,$sql2);
        $count=mysqli_num_rows($res);
        $row=mysqli_fetch_assoc($res);
        $revenue=$row['Total'];

        ?>
        <h1><?php echo $revenue;   ?></h1>

        <?php


        ?>
        Revenue    
    </div>
    

    <div class="clearfix"></div>
    
</div>

    

<?php
include('partials/footer.php');
?>