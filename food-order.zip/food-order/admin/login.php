<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
    <div class="containor">
<center>
     <h1>Login Page</h1>
     <!-- <?php echo $error;  ?> -->
<form method="POST" action="">

<table>
    <tr>
    <th>User name</th>
    </tr>
    
    <tr>
    <th><input type="text" name="uname" placeholder="Enter the user name"></th>
</tr>
<tr>
    <th>Password</th>
</tr>
<tr>
<th><input type="password" name="pass" placeholder="Enter the password">
    <br>

    <br></th>
</tr>
<tr>
    <br>

    <br>
    <br><th><input type="submit" class="btn-primary" name="submit" value="Login" ></th>
</tr>
</table>
</form>

        </center>
    </div>

</body>
</html>
      
<?php
include "connectdb.php";
if(isset($_POST['submit']))
{
    $uname=$_POST['uname'];
    $pass=$_POST['pass'];
    $sql="select * from admin where username='$uname' and password='$pass'";
    $res=mysqli_query($con,$sql);
    $count=mysqli_num_rows($res);
if($count==1)
    {
        // echo "login successfully";
        $_SESSION['login']="<div class='success'>Login successfull</div>";
        $_SESSION['user']=$uname;

        header("location:".siteurl.'admin/index.php');

    }
    else
    {
    echo "invalid username and password";
    }
}





?>


