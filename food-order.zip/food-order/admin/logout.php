<?php
include "connectdb.php";


session_destroy();


header("location:".siteurl.'admin/login.php');



?>