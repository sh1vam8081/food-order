<?php
include('partials/menu.php');
?>
    
    <div class="main-content">
    <div class="wrapper">
     <h1>Manage Admin</h1>
     




     <br>

     <?php

if(isset($_SESSION['add']))
{
    echo $_SESSION['add'];
    unset($_SESSION['add']);
}
if(isset($_SESSION['delete']))
{
    echo $_SESSION['delete'];
    unset($_SESSION['delete']);
}
if(isset($_SESSION['update']))
{
    echo $_SESSION['update'];
    unset($_SESSION['update']);
}
if(isset($_SESSION['user-not-found']))
{
    echo $_SESSION['user-not-found'];
    unset($_SESSION['user-not-found']);
}
if(isset($_SESSION['password-unmatched']))
{
    echo $_SESSION['password-unmatched'];
    unset($_SESSION['password-unmatched']);
}

if(isset($_SESSION['change-password']))
{
    echo $_SESSION['change-password'];
    unset($_SESSION['change-password']);
}

     ?>
     <br>
     <br>



     <button><a href="add-admin.php">ADD ADMIN</a></button>
     <br>
     <br>
    <table class="tbl-full">
        <tr>
            <th>ID</th>
            <th>Full name</th>
            <th>username</th>
            <th>Actions</th>
        </tr>

        <?php
        $sql="select * from admin";

        $res=mysqli_query($con,$sql);
        if($res==true)
        {
            $count=mysqli_num_rows($res);
            
            if($count>0)
            {
                while($rows=mysqli_fetch_assoc($res))
                {
                    $id=$rows['id'];
                    $fname=$rows['fullname'];
                    $uname=$rows['username'];


                    ?>
                       
             <tr>
            
            <td><?php echo $id; ?></td>
                <td><?php echo $fname; ?></td>
                <td><?php echo $uname; ?></td>
                <td><button><a href="<?php echo siteurl; ?>admin/change-password.php?id=<?php echo $id; ?>">Change Password</a></button>
                <td><button><a href="<?php echo siteurl; ?>admin/update-admin.php?id=<?php echo $id; ?>">edit admin</a></button>
                <button><a href="<?php echo siteurl; ?>admin/delete-admin.php?id=<?php echo $id; ?>">delete admin</a></button></td>
                
                
            </tr>

                    <?php






                }
             
            }
            else
            {

            }
        }




        ?>
    </table>
    

    
    
</div>

    <?php
include('partials/footer.php');
?>