<?php
include('partials/menu.php');
?>

<div class="main-content">
    <div class="wrapper">
   
    <h1>manage category</h1>
    <br>
    

    <?php
 if(isset($_SESSION['add-category']))
 {
   echo $_SESSION['add-category'];
   unset ($_SESSION['add-category']);
 }
 if(isset($_SESSION['delete-category']))
 {
   echo $_SESSION['delete-category'];
   unset ($_SESSION['delete-category']);
 }
 if(isset($_SESSION['update']))
 {
    echo $_SESSION['update'];
    unset($_SESSION['update']);
 }
 ?>
 <br>
 <br>
 <br>

     <button><a href="add-category.php" >ADD CATEGORY</a></button>
     <br>
     <br>
    <table class="tbl-full">
        <tr>
            <th>Sr no.</th>
            <th>Title</th>
            <th>Image</th>
            <th>Featured</th>
            <th>Active</th>
            <th>Actions</th>
        </tr>






        <?php

        $sql="select *from category";
        $res=mysqli_query($con,$sql);
        while($row=mysqli_fetch_assoc($res))
        {

            $id=$row['id'];
            $tit=$row['title'];
            $ima=$row['image'];
            $fea=$row['featured'];
            $act=$row['active'];
        
        
        ?>



             <tr>
            <td><?php echo $id; ?></td>
            <td><?php echo $tit; ?></td>
            <td>
                <?php
                if($ima)
                {
                   ?>
                   <img src="<?php echo siteurl; ?>images/category/<?php echo $ima; ?>" width='80px'>
                   <?php
                }
                ?>
            </td>
            <td><?php echo $fea; ?></td>
            <td><?php echo $act; ?></td>
            <td><button><a href="<?php echo siteurl; ?>admin/update-category.php?id=<?php echo $id; ?>" >update category</a></button>
            <button><a href="<?php echo siteurl; ?>admin/delete-category.php?id=<?php echo $id; ?>&image_name=<?php echo $ima;  ?>">delete category</a></button></td>
     
             </tr>

             <?php
        }
        

        ?>
    </table>
    
</div></div>



<?php
include('partials/footer.php');
?>


    
            