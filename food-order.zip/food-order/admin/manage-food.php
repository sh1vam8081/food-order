<?php
include('partials/menu.php');
?>

<div class="main-content">
    <div class="wrapper">

    <h1>manage food</h1>
    <br>
    <?php
if(isset($_SESSION['add-food']))
{
    echo $_SESSION['add-food'];
    unset($_SESSION['add-food']);
}
if(isset($_SESSION['delete-food']))
{
    echo $_SESSION['delete-food'];
    unset($_SESSION['delete-food']);
}

if(isset($_SESSION['updatefood']))
{
  echo $_SESSION['updatefood'];
  unset ($_SESSION['updatefood']);
}

?>
<br>
<br>
   <button>  <a href="add-food.php">ADD FOOD</a></button>
     <br>
     <br>
    <table class="tbl-full">
        <tr>
            <th>id.</th>
            <th>Title</th>
            <th>description</th>
            <th>price</th>
            <th>Image</th>
            <th>category_id</th>
            <th>featured</th>
            <th>Active</th>
            <th>Action</th>
        </tr>


        <?php 
        $sql="select * from food";
        $res=mysqli_query($con,$sql);
        while($row=mysqli_fetch_assoc($res))
        {

            $id=$row['id'];
            $title=$row['title'];
            $description=$row['description'];
            $price=$row['price'];
            $image_name=$row['image_name'];
            $category_id=$row['category_id'];
            $featured=$row['featured'];
            $active=$row['active'];
        
        
        
        ?>


        <tr>
            
            <td><?php echo $id; ?> </td>
            <td><?php echo $title; ?></td>
            <td><?php echo $description; ?></td>
            <td><?php echo $price; ?> </td>
             <td>
                <?php
                   if($image_name)
                   {
                    ?>
                    <img src="<?php echo siteurl; ?>images/food/<?php echo $image_name; ?>" width='180px'>
                    <?php
                   }



                 ?>
                
                 </td>
            <td><?php echo $category_id; ?> </td>
            <td><?php echo $featured; ?> </td>
            <td><?php echo $active; ?> </td>

            <td><button><a href="<?php echo siteurl; ?>admin/update-food.php?id=<?php echo $id; ?>" >edit food</a></button>
           <button> <a href="<?php echo siteurl; ?>admin/delete-food.php?id=<?php echo $id; ?>" >delete food</a></button></td>

            
        </tr>
        <?php

        }
        ?>
        
    </table>
    
</div></div>


<?php
include('partials/footer.php');
?>
