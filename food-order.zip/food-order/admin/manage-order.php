

<?php
include('partials/menu.php');
?>
    



    <div class="main-content">
    <div class="wrapper">

    <?php
if(isset($_SESSION['order-cancel']))
{
    echo $_SESSION['order-cancel'];
    unset($_SESSION['order-cancel']);
}

?>
     <h1>Manage order</h1> <br>
    
    <table class="tbl-full">
        <tr>
            <th>id</th>
            <th>Food name</th>
            <th>price</th>
            <th>quantity</th>
            <th>total amount</th>
            <th>order date</th>
            <th>status</th>
            <th>customer_name</th>
            <th>customer_contact</th>
            <th>customer_email</th>
            <th>Customer Address</th>
            <th>Action</th>
            
        </tr>

        <tr>
            <?php
            $sql="select * from tbl_order";
            $res=mysqli_query($con,$sql);
             while($row=mysqli_fetch_assoc($res))
             {
                $id=$row['id'];
                $food=$row['food'];
                $price=$row['price'];
                $qty=$row['qty'];
                $total=$row['total'];
                $order_date=$row['order_date'];
                $status=$row['status'];
                $cust_name=$row['customer_name'];
                $cust_contact=$row['customer_contact'];
                $cust_email=$row['customer_email'];
                $cust_address=$row['customer_address'];


                ?>
                <tr>
            <td><?php echo $id ?></td>
            <td><?php echo $food  ?></td>
            <td><?php echo $price ?></td>
            <td><?php echo $qty  ?></td>
            <td><?php echo $total ?></td>
            <td><?php echo $order_date ?></td>
            <td><?php  echo $status ?></td>
            <td><?php  echo $cust_name ?></td>
            <td><?php  echo $cust_contact ?></td>
            <td><?php  echo $cust_email ?></td>
            <td><?php  echo $cust_address ?></td>
            <td><button><a href="<?php echo siteurl; ?>/admin/delete_order.php?id=<?php echo $id; ?>">cancel order</a></button></td>

            
            </tr>
               <?php


             }

        





             ?>
        
        
    </table>
    

    
    

    <div class="clearfix"></div>
    
</div>


    <?php
include('partials/footer.php');
?>