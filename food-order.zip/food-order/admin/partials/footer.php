
    <!-- footer part starts -->
    <div class="footer">
    <div class="wrapper">
        <p>2023 all rights reserved,some resturant, devloped by<a href=""> shivam verma</a></p>
    </div></div>
    <!-- footer part ends -->
    
</body>

</html>