<?php

if(!isset($_SESSION['user']))
{
    $_SESSION['no-login']="<div class='error'>please login to access</div>";

    header("location:".siteurl.'admin/login.php');

}


?>