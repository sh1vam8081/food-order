
<?php include "connectdb.php"; 
include 'login-check.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../css/admin.css">
</head>
<body>
<div class="menu">
        <div class="wrapper">
            <ul><center>
                <li><a href="index.php">Home</a></li>
                <li><a href="manage-admin.php">Admin</a></li>
                <li><a href="manage-category.php">Catagory</a></li>
                <li><a href="manage-food.php">food</a></li>
                <li><a href="manage-order.php">order</a></li>
                <li><a href="logout.php">logout</a></li>

                </center>

            </ul>

        </div>
    </div>
    

