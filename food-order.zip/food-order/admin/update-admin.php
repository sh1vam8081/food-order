<?php
include('partials/menu.php');
?>
<div class="main-content">
    <div class="wrapper">
     <h1>Update Admin</h1>
<br>
<br>
<?php

$id=$_GET['id'];
$sql="select * from admin where id='$id'";
$res=mysqli_query($con,$sql);
$row=mysqli_fetch_assoc($res);
 $fname=$row['fullname'];
$uname=$row['username'];

?>

<form action="" method="POST">
        <table>
            <tr>
                <td>Fullname:<br><input type="text" name="fname" placeholder="Enter admin full name" value="<?php echo $fname; ?>"></td></tr>
               <tr> <td>Username:<br><input type="text" name="uname" placeholder="Enter  username" value="<?php echo $uname; ?>"></td></tr>
                <tr><td><input type="submit"  name="submit" value="update"></td></tr>

            </tr>
        </table>
    </form>
    </div></div>


    <?php
    
    if(isset($_POST['submit']))
    {
        $id=$_GET['id'];
        $fname=$_POST['fname'];
        $uname=$_POST['uname'];
        $sql="update admin set fullname='$fname',username='$uname' where id='$id' ";
        $res=mysqli_query($con,$sql);
        if($res)
        {
          $_SESSION['update']="data updated successfully";
    header("location:".siteurl.'admin/manage-admin.php');

        }
    }
     ?>








<?php
include('partials/footer.php');
?>

