<?php
include('partials/menu.php');
?>
<div class="main-content">
    <div class="wrapper">
     <h1>Update Category</h1>
<br>
<br>
<?php

$id=$_GET['id'];
$sql="select * from category where id='$id'";
$res=mysqli_query($con,$sql);
$row=mysqli_fetch_assoc($res);
 
$id=$row['id'];
$tit=$row['title'];
$image=$row['image'];
$featured=$row['featured'];
$active=$row['active'];

?>



<form method="POST" action="" enctype="multipart/form-data">

        <table>
    
       <tr>   
       <td>title:</td>
       <td><input type="text" name="title" value="<?php echo $tit; ?>"></td>
       </tr>
       
         <tr>
       <td>Current Image:</td>
       <td> <img src="<?php echo siteurl;?>images/category/<?php echo $image;  ?>" height='100px';>
         </td>
</tr>
         
       <tr>   
       <td>New Image:</td>
       <td><input type="file" name="image" value=""></td>
       </tr>
      
       <tr>
       <td>featured:</td>
       



       <td><input type="radio" name="featured" value="YES" 
       <?php
       if($featured=="YES")
       {
        echo 'checked';
       }
       ?>
       
       
       
       >YES
       <input type="radio" name="featured" value="NO"
       <?php
       if($featured=="NO")
       {
        echo 'checked';
       }
       ?>
       >NO
         </td>
       </tr>
       
       <tr>   
       <td>Active:</td>
       <td><input type="radio" name="active" value="YES"
       <?php
       if($active=="YES")
       {
        echo 'checked';
       }
       ?>
       >YES
       <input type="radio" name="active" value="NO"
       <?php
       if($active=="NO")
       {
        echo 'checked';
       }
       ?>
       >NO
         </td>

       </tr>
       
       <tr>
       <td><input type="submit" value="update" name="submit"></td>
</tr>
        </table>
    </form>


    <?php
    
    if(isset($_POST['submit']))
    {
        $id=$_GET['id'];
        $title=$_POST['title'];
        if(isset($_FILES['image']['name']))
        {
          $image=$_FILES['image']['name'];
          $sourse_path=$_FILES['image']['tmp_name'];
          $des_path="../images/category/".$image;
          $upload=move_uploaded_file($sourse_path,$des_path);
          if($upload==false)
          {
             $_SESSION['upload-fail']="file uploading is falied";
          }
     
        }
     
        $featured=$_POST['featured'];
        $active=$_POST['active'];

        $sql1="update category set title='$title',image='$image',featured='$featured',active='$active' where id='$id' ";
        $res1=mysqli_query($con,$sql1);
        if($res1)
        {
          $_SESSION['update']="data updated successfully";
          header("location:".siteurl.'admin/manage-category.php');

        }
    }



     ?>

    </div>
</div>
<?php
include('partials/footer.php');
?>

