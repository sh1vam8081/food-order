<?php include('partials/menu.php')  ?>

<div class="main-content">
    <div class="wrapper">
     <h1>Update Food</h1>
<br>
<br>
<?php
$id=$_GET['id'];
$sql="select * from food where id='$id'";
$res=mysqli_query($con,$sql);
$row=mysqli_fetch_assoc($res);

$title=$row['title'];
$description=$row['description'];
$price=$row['price'];
$image_name=$row['image_name'];
$featured=$row['featured'];
$active=$row['active'];




?>




<form method="post" enctype="multipart/form-data" action="">


Title:<input type="text" name="title" value="<?php echo $title; ?>"><br><br>
Description:<input type="text" name="description" value="<?php echo $description; ?>"><br><br>
Price:<input type="text" name="price" value="<?php echo $price; ?>"><br><br>
Current Image:
<img src="<?php echo siteurl;?>images/category/<?php echo $image_name;  ?>" height='100px';>
         
<br><br>
New Image:<input type="file" name="image" value=""><br><br>
Featured:<input type="radio" name="featured" value="YES"
<?php
 if($featured=="YES")
 {
    echo 'checked';
 }
 ?>

 >YES <input type="radio" name="featured" value="NO"
<?php
 if($featured=="NO")
 {
    echo 'checked';
 }


?>

>NO<br><br>
Active:<input type="radio" name="active" value="YES"
<?php
 if($active=="YES")
 {
    echo 'checked';
 }
?>

 >YES <input type="radio" name="active" value="NO"
 
 <?php
 if($active=="NO")
 {
    echo 'checked';
 }
 ?>
 >NO<br><br>
<input type="submit" name="submit" value="update"><br><br>

</form>

<?php
$id=$_GET['id'];
if(isset($_POST['submit']))
{
    $ntitle=$_POST['title'];
    $ndescription=$_POST['description'];
    $nprice=$_POST['price'];

    if(isset($_FILES['image']['name']))
    {
      $image=$_FILES['image']['name'];
      $sourse_path=$_FILES['image']['tmp_name'];
      $des_path="../images/category/".$image;
      $upload=move_uploaded_file($sourse_path,$des_path);
  
}


    $nfeatured=$_POST['featured'];
    $nactive=$_POST['active'];

    $sql2="update food set title='$ntitle',description='$ndescription',price='$nprice',image_name='$image',featured='$nfeatured',active='$nactive' where id='$id'";
    $res=mysqli_query($con,$sql2);
    if($res)
    {
        $_SESSION['updatefood']="food updated successfully";
    
        header("location:".siteurl.'admin/manage-food.php');
        

    }
    else{
        echo "updation failed";
    }



    

}





?>


    </div>
</div>
<?php include('partials/footer.php')  ?>
