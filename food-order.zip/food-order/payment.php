
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<div class="div">
    <form action="" method="POST">
        <h2>Enter your Card details</h2><br><br>
    <h3> Card Holder's name</h3> <input type="text" name="name"><br><br>
    <h3> Card Number</h3><input type="number" name="num"><br><br>
 <h3>Valid thru</h3><input type="date" name="date"><br><br>
    <h3> Cvv Number</h3><input type="number" name="cvv"><br><br>
            <input type="submit" value="Add card">
        </form>
    </div>
</body>
</html>


<?php

$con=mysqli_connect("localhost","root","","food-order");

    if(isset($_POST['submit'])){
        
       $n= $_POST['name'];
       $num= $_POST['num'];
       $d= $_POST['date'];
       $c=$_POST['cvv'];
       $con=mysqli_connect("localhost","root","root","library_management");
       $sql="insert into card_details(holderName,cardNum,valid,cvv) values('$n','$num','$d','$c')";
      $res=mysqli_query($con,$sql);
      if($res)
      {
        echo "card details added successfully";

      }
      else{
        echo "fill correct card details ";
      }



    }
      
?>
    